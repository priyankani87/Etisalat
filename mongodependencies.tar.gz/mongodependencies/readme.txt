




cp openssl.config /etc/crypto-policies/back-ends/

cp opensslcnf.config /etc/crypto-policies/back-ends/

cp -r openssl /etc/pki/ca-trust/extracted/

cp openssl10.cnf /etc/pki

#cp -r crypto-policies /usr/share/

cp -r compat-openssl10 /usr/share/doc

cp -r compat-openssl10 /usr/share/licenses

 
