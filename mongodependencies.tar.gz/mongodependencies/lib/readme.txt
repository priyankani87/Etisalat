/usr/share/licenses/libcurl-minimal
